// Skin specific Javascript
if ("scImageMgr" in window) scImageMgr.fOverAlpha=.9;
